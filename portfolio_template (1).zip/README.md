# Ready-to-deploy UI/UX Portfolio Template

This is a simple, responsive single-page portfolio template built for quick deployment on GitHub Pages (free) or any static host.

## Files
- `index.html` — main page
- `styles.css` — simple modern styles
- `README.md` — this file

---

## Quick Publish on GitHub Pages (Free + Custom Domain)

1. Create a GitHub repository (public).
2. Upload the files (`index.html` and `styles.css`) to the repository root.
3. In the repo, go to **Settings → Pages** (or: Settings → Pages & scroll to "Build and deployment").
4. Under "Source", select **Branch: main** and folder **/(root)** then Save.
5. GitHub will publish at `https://<your-username>.github.io/<repo-name>/` within a minute.

### To use a custom domain:
- Go to Settings → Pages → Custom domain and add `example.com` (your domain).
- Create DNS records at your domain host:
  - For apex domain (`example.com`) add A records pointing to GitHub Pages IPs:
    - 185.199.108.153
    - 185.199.109.153
    - 185.199.110.153
    - 185.199.111.153
  - For `www.example.com` add a CNAME record pointing to `<your-username>.github.io`.
- Wait for DNS to propagate (usually minutes to a few hours).
- GitHub will provision HTTPS automatically.

---

## Notes & Next Steps
- Replace placeholder text (Your Name, email, project descriptions).
- Add images/screenshots by placing them in the repo and updating `index.html`.
- If you want me to customize the template (add your name, hero text, projects, and portrait), tell me your details and I will update the files for you.
